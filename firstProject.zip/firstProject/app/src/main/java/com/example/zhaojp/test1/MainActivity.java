package com.example.zhaojp.test1;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.ashokvarma.bottomnavigation.BottomNavigationItem;

public class MainActivity extends AppCompatActivity {

    //菜单栏
    private BottomNavigationBar mBottomNavigationBar;

    /*//AndroidImageSlider实现轮播图
    private SliderLayout sliderShow;*/


    FragmentManager fragmentManager;
    FragmentTransaction transaction;
    private home homePage;
    private login loginPage;
    private register registerPage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /*//图片轮播
        sliderShow = (SliderLayout) findViewById(R.id.slider);
        imageSlider();*/


        //菜单导航栏
        mBottomNavigationBar = findViewById(R.id.bottom_navigation_bar);

        mBottomNavigationBar.setMode(BottomNavigationBar.MODE_SHIFTING)
                .setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_RIPPLE);


        mBottomNavigationBar
                .addItem(new BottomNavigationItem(R.drawable.home, "Home"))
                .addItem(new BottomNavigationItem(R.drawable.login, "Login"))
                .addItem(new BottomNavigationItem(R.drawable.register, "Register"))
                .addItem(new BottomNavigationItem(R.drawable.trainer, "Trainer"))
                .addItem(new BottomNavigationItem(R.drawable.classe, "Classe"))
                .initialise();

        setDefaultFragment();

        //菜单导航栏监听（跳转）
        mBottomNavigationBar.setTabSelectedListener(new BottomNavigationBar.OnTabSelectedListener() {
            @Override
            public void onTabSelected(int position) {
                //未选中->选中
                if (position == 0) {
                    if (homePage == null) {
                        homePage = new home();
                    }
                    getFragmentManager().beginTransaction().replace(R.id.fragment_content, homePage).commitAllowingStateLoss();
                } else if (position == 1) {
                    if (loginPage == null) {
                        loginPage = new login();
                    }
                    getFragmentManager().beginTransaction().replace(R.id.fragment_content, loginPage).commitAllowingStateLoss();
                } else if (position == 2) {
                    if (registerPage == null) {
                        registerPage = new register();
                    }
                    getFragmentManager().beginTransaction().replace(R.id.fragment_content, registerPage).commitAllowingStateLoss();
                }


            }

            @Override
            public void onTabUnselected(int position) {
                //选中->未选中
            }

            @Override
            public void onTabReselected(int position) {
                //选中->选中
            }
        });



    }


    //默认界面
    private void setDefaultFragment(){
        fragmentManager = getFragmentManager();
        transaction = fragmentManager.beginTransaction();
        homePage = new home();
        transaction.add(R.id.fragment_content,homePage);
        transaction.commitAllowingStateLoss();
    }

}
