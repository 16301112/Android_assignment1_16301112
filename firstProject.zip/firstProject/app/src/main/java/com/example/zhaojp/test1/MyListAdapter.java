package com.example.zhaojp.test1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyListAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater layoutInflater;

    public MyListAdapter(Context context){
        this.context=context;
        layoutInflater=LayoutInflater.from(context);
    }


    @Override
    public int getCount() {
        return 20;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    static  class ViewHolder{
        public ImageView imageView;
        public TextView textName,textItem,textContent;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder=null;

        if(convertView==null){
            convertView=layoutInflater.inflate(R.layout.layout_list_item,null);
            holder=new ViewHolder();
            holder.imageView=convertView.findViewById(R.id.imageView);
            holder.textName=convertView.findViewById(R.id.textName);
            holder.textContent=convertView.findViewById(R.id.textContent);
            convertView.setTag(holder);
        }
        else{
            holder= (ViewHolder) convertView.getTag();
        }

        //控件赋值
        holder.textName.setText("bbb");
        holder.textItem.setText("篮球");
        holder.textContent.setText("教练主要从事...");


        return convertView;
    }
}
