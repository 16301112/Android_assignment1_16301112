package com.example.zhaojp.test1;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class trainer extends AppCompatActivity {

    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainer);

        lv=findViewById(R.id.listTrainer);
        lv.setAdapter(new MyListAdapter(trainer.this));
    }
}
